package com.senscalc.freefire.data.repository

import com.senscalc.freefire.data.db.ProfileDao
import com.senscalc.freefire.data.db.toDomain
import com.senscalc.freefire.data.db.toEntity
import com.senscalc.freefire.data.model.SensitivityProfile
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * Single source of truth for saved sensitivity profiles, backed by
 * the Room database. Exposes domain models only, so the rest of the
 * app never touches ProfileEntity directly.
 */
class ProfileRepository(private val dao: ProfileDao) {

    fun observeProfiles(): Flow<List<SensitivityProfile>> =
        dao.observeAll().map { list -> list.map { it.toDomain() } }

    suspend fun getProfile(id: Long): SensitivityProfile? = dao.getById(id)?.toDomain()

    suspend fun saveNew(profile: SensitivityProfile): Long = dao.insert(profile.toEntity())

    suspend fun update(profile: SensitivityProfile) {
        dao.update(profile.copy(updatedAtMillis = System.currentTimeMillis()).toEntity())
    }

    suspend fun delete(profile: SensitivityProfile) = dao.delete(profile.toEntity())

    suspend fun deleteById(id: Long) = dao.deleteById(id)

    suspend fun setStarred(id: Long, starred: Boolean) =
        dao.setStarred(id, starred, System.currentTimeMillis())
}
