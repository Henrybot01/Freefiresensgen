package com.senscalc.freefire.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.senscalc.freefire.ui.components.DarkCard
import com.senscalc.freefire.ui.components.ScreenTopBar
import com.senscalc.freefire.ui.theme.AccentAmber
import com.senscalc.freefire.ui.theme.AccentNeonGreen
import com.senscalc.freefire.ui.theme.BackgroundDeep
import com.senscalc.freefire.ui.theme.SurfaceCardElevated
import com.senscalc.freefire.ui.theme.SurfaceStroke
import com.senscalc.freefire.ui.theme.TextPrimary
import com.senscalc.freefire.ui.theme.TextSecondary
import kotlin.math.hypot

/**
 * Lets the user drag a finger across a canvas and see, live, how a
 * given "sensitivity" value would translate that physical drag into
 * crosshair movement — including a simple resistance/friction curve
 * so higher sensitivity feels faster but also less precise, and a
 * "drag-up speed" readout modeling how quickly full recoil compensation
 * (a full vertical swipe) would be achieved.
 */
@Composable
fun DragSimulatorScreen(onBack: () -> Unit) {
    var simulatedSensitivity by remember { mutableFloatStateOf(100f) }
    var crosshairOffset by remember { mutableStateOf(Offset.Zero) }
    var lastDragDistance by remember { mutableFloatStateOf(0f) }
    var dragUpSpeed by remember { mutableFloatStateOf(0f) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDeep)
            .padding(horizontal = 20.dp)
    ) {
        ScreenTopBar(title = "Drag Physics Simulator", subtitle = "Preview crosshair resistance & drag-up speed", onBack = onBack)

        DarkCard(modifier = Modifier.fillMaxWidth()) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Simulated Sensitivity", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                Text("${simulatedSensitivity.toInt()}", style = MaterialTheme.typography.titleLarge, color = TextPrimary, fontWeight = FontWeight.Bold)
            }
            Slider(
                value = simulatedSensitivity,
                onValueChange = { simulatedSensitivity = it },
                valueRange = 0f..200f,
                colors = SliderDefaults.colors(
                    thumbColor = AccentNeonGreen,
                    activeTrackColor = AccentNeonGreen,
                    inactiveTrackColor = SurfaceCardElevated
                )
            )
        }

        Spacer(Modifier.height(16.dp))

        DarkCard(modifier = Modifier.fillMaxWidth()) {
            Text("Drag anywhere below to test crosshair response", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
            Spacer(Modifier.height(12.dp))

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .background(SurfaceCardElevated)
                    .pointerInput(simulatedSensitivity) {
                        detectDragGestures(
                            onDragStart = {
                                crosshairOffset = Offset.Zero
                            },
                            onDrag = { change, dragAmount ->
                                change.consume()

                                // Resistance grows with sensitivity: very high
                                // sensitivity overshoots more easily (less precise),
                                // modeled as a mild non-linear damping curve.
                                val sensFactor = (simulatedSensitivity / 100f).coerceIn(0.05f, 2.5f)
                                val resistance = 1f / (1f + (sensFactor - 1f).coerceAtLeast(0f) * 0.15f)
                                val effectiveDx = dragAmount.x * sensFactor * resistance
                                val effectiveDy = dragAmount.y * sensFactor * resistance

                                crosshairOffset = Offset(
                                    (crosshairOffset.x + effectiveDx),
                                    (crosshairOffset.y + effectiveDy)
                                )
                                lastDragDistance = hypot(dragAmount.x, dragAmount.y)
                                dragUpSpeed = (-effectiveDy).coerceAtLeast(0f)
                            }
                        )
                    }
            ) {
                val center = Offset(size.width / 2f, size.height / 2f)

                // Grid backdrop
                val step = size.width / 8f
                var x = 0f
                while (x <= size.width) {
                    drawLine(SurfaceStroke, Offset(x, 0f), Offset(x, size.height), strokeWidth = 1f)
                    x += step
                }
                var y = 0f
                while (y <= size.height) {
                    drawLine(SurfaceStroke, Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
                    y += step
                }

                // Clamp the crosshair visually within the canvas bounds
                val maxRadius = size.minDimension / 2f - 20f
                val rawTarget = Offset(center.x + crosshairOffset.x, center.y + crosshairOffset.y)
                val delta = rawTarget - center
                val dist = hypot(delta.x, delta.y)
                val clampedTarget = if (dist > maxRadius && dist > 0f) {
                    center + delta * (maxRadius / dist)
                } else rawTarget

                drawCircle(color = SurfaceStroke, radius = maxRadius, center = center, style = Stroke(width = 2f))

                // Crosshair
                drawLine(AccentNeonGreen, Offset(clampedTarget.x - 20f, clampedTarget.y), Offset(clampedTarget.x + 20f, clampedTarget.y), strokeWidth = 4f)
                drawLine(AccentNeonGreen, Offset(clampedTarget.x, clampedTarget.y - 20f), Offset(clampedTarget.x, clampedTarget.y + 20f), strokeWidth = 4f)
                drawCircle(color = AccentNeonGreen, radius = 6f, center = clampedTarget)

                // Center reference dot
                drawCircle(color = AccentAmber, radius = 4f, center = center)
            }
        }

        Spacer(Modifier.height(16.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ReadoutCard(label = "Last Drag Distance", value = "${lastDragDistance.toInt()} px", modifier = Modifier.weight(1f))
            ReadoutCard(label = "Drag-Up Speed", value = "${dragUpSpeed.toInt()} px/frame", modifier = Modifier.weight(1f))
        }

        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun ReadoutCard(label: String, value: String, modifier: Modifier = Modifier) {
    DarkCard(modifier = modifier) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = TextSecondary)
        Spacer(Modifier.height(6.dp))
        Text(value, style = MaterialTheme.typography.titleLarge, color = AccentNeonGreen, fontWeight = FontWeight.Bold)
    }
}
