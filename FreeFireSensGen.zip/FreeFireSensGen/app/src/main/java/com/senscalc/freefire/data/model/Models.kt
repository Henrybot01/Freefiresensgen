package com.senscalc.freefire.data.model

/**
 * Relative friction of the glass/coating on a device's screen.
 * Higher friction generally requires slightly lower sensitivity values
 * because the finger travels a shorter effective distance for the same
 * physical swipe, while low-friction (very slick) glass needs the
 * opposite compensation.
 */
enum class GlassFriction(val label: String, val factor: Double) {
    HIGH("High Friction (Matte / Textured)", 0.90),
    MEDIUM("Medium Friction (Standard Glass)", 1.00),
    LOW("Low Friction (Ultra Slick / Glossy)", 1.10)
}

/**
 * Rough chipset performance tier. This drives touch-polling stability
 * and frame-pacing consistency, which in turn affects how aggressive
 * sensitivity values can safely be.
 */
enum class ChipsetTier(val label: String, val tier: Int) {
    ENTRY("Entry Level", 1),
    LOWER_MID("Lower Mid-Range", 2),
    UPPER_MID("Upper Mid-Range", 3),
    FLAGSHIP("Flagship", 4),
    ELITE("Elite / Top-Tier", 5)
}

/**
 * A hardware profile, either pulled from the built-in device database
 * or created manually via the Custom Device Profile Builder.
 */
data class DeviceProfile(
    val id: String,
    val brand: String,
    val model: String,
    val refreshRateHz: Int,
    val touchSamplingHz: Int,
    val chipsetTier: ChipsetTier,
    val glassFriction: GlassFriction,
    val screenDpi: Int,
    val ramGb: Int,
    val isCustom: Boolean = false
)

/**
 * The six sensitivity axes Free Fire exposes, each on a 0-200 scale.
 */
data class SensitivityValues(
    val general: Int,
    val redDot: Int,
    val scope2x: Int,
    val scope4x: Int,
    val sniperScope: Int,
    val freeLook: Int
) {
    fun clampAll(): SensitivityValues = SensitivityValues(
        general = general.coerceIn(0, 200),
        redDot = redDot.coerceIn(0, 200),
        scope2x = scope2x.coerceIn(0, 200),
        scope4x = scope4x.coerceIn(0, 200),
        sniperScope = sniperScope.coerceIn(0, 200),
        freeLook = freeLook.coerceIn(0, 200)
    )
}

/**
 * Full calculation result: the six sensitivity values plus the two
 * supplementary recommendations (fire button size and target DPI).
 */
data class SensitivityResult(
    val values: SensitivityValues,
    val fireButtonSizePercent: Int,
    val targetDpi: Int
)

/**
 * A named preset from the Meta & Preset Library. Presets act as
 * "starting points" — multipliers applied on top of a device's
 * calculated baseline rather than fixed absolute numbers, so they
 * still respect the user's hardware.
 */
data class MetaPreset(
    val id: String,
    val title: String,
    val description: String,
    val generalMult: Double,
    val redDotMult: Double,
    val scope2xMult: Double,
    val scope4xMult: Double,
    val sniperMult: Double,
    val freeLookMult: Double
)

/**
 * Claw/grip style used for the HUD Grip Blueprint diagrams.
 */
enum class GripStyle(val label: String, val fingerCount: Int) {
    TWO_FINGER("2-Finger Claw", 2),
    THREE_FINGER("3-Finger Claw", 3),
    FOUR_FINGER("4-Finger Claw", 4)
}

/**
 * A saved user profile combining a device, the calculated (or manually
 * fine-tuned) sensitivity values, and metadata for local persistence.
 */
data class SensitivityProfile(
    val id: Long = 0L,
    val name: String,
    val deviceLabel: String,
    val values: SensitivityValues,
    val fireButtonSizePercent: Int,
    val targetDpi: Int,
    val isStarred: Boolean = false,
    val createdAtMillis: Long = System.currentTimeMillis(),
    val updatedAtMillis: Long = System.currentTimeMillis()
)
