package com.senscalc.freefire.ui.theme

import androidx.compose.ui.graphics.Color

// Deep, near-black backgrounds layered for depth, inspired by WHOOP's
// dashboard: matte charcoal surfaces with a single vivid accent used
// sparingly for emphasis (strain/recovery style highlight).
val BackgroundDeep = Color(0xFF0A0B0D)
val SurfaceCard = Color(0xFF15171A)
val SurfaceCardElevated = Color(0xFF1D2024)
val SurfaceStroke = Color(0xFF2A2E33)

val AccentNeonGreen = Color(0xFF33FFB4)   // "Recovery" style accent
val AccentNeonBlue = Color(0xFF3DD9FF)    // secondary accent
val AccentAmber = Color(0xFFFFB13D)       // caution / mid values
val AccentRed = Color(0xFFFF4D4D)         // strain / high values

val TextPrimary = Color(0xFFF5F6F7)
val TextSecondary = Color(0xFF9AA1A8)
val TextTertiary = Color(0xFF676D73)

val DividerColor = Color(0xFF23262A)
