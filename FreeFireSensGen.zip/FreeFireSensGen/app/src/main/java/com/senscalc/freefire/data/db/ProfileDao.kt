package com.senscalc.freefire.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ProfileDao {

    @Query("SELECT * FROM sensitivity_profiles ORDER BY isStarred DESC, updatedAtMillis DESC")
    fun observeAll(): Flow<List<ProfileEntity>>

    @Query("SELECT * FROM sensitivity_profiles WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): ProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: ProfileEntity): Long

    @Update
    suspend fun update(entity: ProfileEntity)

    @Delete
    suspend fun delete(entity: ProfileEntity)

    @Query("DELETE FROM sensitivity_profiles WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("UPDATE sensitivity_profiles SET isStarred = :starred, updatedAtMillis = :timestamp WHERE id = :id")
    suspend fun setStarred(id: Long, starred: Boolean, timestamp: Long)
}
