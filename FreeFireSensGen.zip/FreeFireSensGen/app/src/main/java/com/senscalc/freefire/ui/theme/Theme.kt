package com.senscalc.freefire.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val WhoopInspiredDarkScheme = darkColorScheme(
    primary = AccentNeonGreen,
    onPrimary = BackgroundDeep,
    secondary = AccentNeonBlue,
    onSecondary = BackgroundDeep,
    tertiary = AccentAmber,
    onTertiary = BackgroundDeep,
    error = AccentRed,
    onError = TextPrimary,
    background = BackgroundDeep,
    onBackground = TextPrimary,
    surface = SurfaceCard,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceCardElevated,
    onSurfaceVariant = TextSecondary,
    outline = SurfaceStroke,
    outlineVariant = DividerColor
)

@Composable
fun FreeFireSensGenTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // The app is intentionally always-dark (WHOOP-style), regardless of
    // system setting, to keep the neon accent contrast consistent.
    MaterialTheme(
        colorScheme = WhoopInspiredDarkScheme,
        typography = AppTypography,
        content = content
    )
}
