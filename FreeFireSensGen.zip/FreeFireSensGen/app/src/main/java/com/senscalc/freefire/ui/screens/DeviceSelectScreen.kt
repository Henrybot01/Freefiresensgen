package com.senscalc.freefire.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.senscalc.freefire.data.DeviceDatabase
import com.senscalc.freefire.data.model.DeviceProfile
import com.senscalc.freefire.ui.components.ScreenTopBar
import com.senscalc.freefire.ui.theme.AccentNeonGreen
import com.senscalc.freefire.ui.theme.BackgroundDeep
import com.senscalc.freefire.ui.theme.SurfaceCard
import com.senscalc.freefire.ui.theme.SurfaceCardElevated
import com.senscalc.freefire.ui.theme.TextPrimary
import com.senscalc.freefire.ui.theme.TextSecondary
import com.senscalc.freefire.viewmodel.SensitivityViewModel

@Composable
fun DeviceSelectScreen(
    viewModel: SensitivityViewModel,
    onDeviceChosen: () -> Unit,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDeep)
            .padding(horizontal = 20.dp)
    ) {
        ScreenTopBar(title = "Select Device", subtitle = "${DeviceDatabase.devices.size} devices available", onBack = onBack)
        Spacer(Modifier.height(8.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(20.dp),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) {
            items(DeviceDatabase.brands) { brand ->
                Column {
                    Text(
                        brand.uppercase(),
                        style = MaterialTheme.typography.labelLarge,
                        color = AccentNeonGreen
                    )
                    Spacer(Modifier.height(10.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        DeviceDatabase.devicesForBrand(brand).forEach { device ->
                            DeviceRow(device = device) {
                                viewModel.selectDevice(device)
                                onDeviceChosen()
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DeviceRow(device: DeviceProfile, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(SurfaceCard)
            .clickable { onClick() }
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text(device.model, style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text(
                "${device.refreshRateHz}Hz  •  ${device.touchSamplingHz}Hz touch  •  ${device.chipsetTier.label}",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
        }
        Column(
            modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .background(SurfaceCardElevated)
                .padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            Text("${device.screenDpi} DPI", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        }
    }
}
