package com.senscalc.freefire.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.senscalc.freefire.data.model.SensitivityProfile
import com.senscalc.freefire.ui.components.ScreenTopBar
import com.senscalc.freefire.ui.components.StarToggle
import com.senscalc.freefire.ui.theme.AccentNeonGreen
import com.senscalc.freefire.ui.theme.AccentRed
import com.senscalc.freefire.ui.theme.BackgroundDeep
import com.senscalc.freefire.ui.theme.SurfaceCard
import com.senscalc.freefire.ui.theme.SurfaceCardElevated
import com.senscalc.freefire.ui.theme.TextPrimary
import com.senscalc.freefire.ui.theme.TextSecondary
import com.senscalc.freefire.viewmodel.SensitivityViewModel

@Composable
fun ProfilesScreen(
    viewModel: SensitivityViewModel,
    onBack: () -> Unit,
    onOpenProfile: () -> Unit
) {
    val profiles by viewModel.savedProfiles.collectAsState()
    var editingProfile by remember { mutableStateOf<SensitivityProfile?>(null) }
    var editName by remember { mutableStateOf("") }
    var deletingProfile by remember { mutableStateOf<SensitivityProfile?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDeep)
            .padding(horizontal = 20.dp)
    ) {
        ScreenTopBar(title = "Saved Profiles", subtitle = "${profiles.size} saved", onBack = onBack)

        if (profiles.isEmpty()) {
            Spacer(Modifier.height(16.dp))
            Text(
                "No saved profiles yet. Generate a sensitivity and tap Save Profile.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(vertical = 12.dp, bottom = 32.dp)
        ) {
            items(profiles, key = { it.id }) { profile ->
                ProfileRow(
                    profile = profile,
                    onOpen = {
                        viewModel.loadProfileIntoEditor(profile)
                        onOpenProfile()
                    },
                    onToggleStar = { viewModel.toggleStar(profile) },
                    onEdit = {
                        editingProfile = profile
                        editName = profile.name
                    },
                    onDelete = { deletingProfile = profile }
                )
            }
        }
    }

    editingProfile?.let { profile ->
        AlertDialog(
            onDismissRequest = { editingProfile = null },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.updateProfile(profile.copy(name = editName.ifBlank { profile.name }))
                        editingProfile = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AccentNeonGreen, contentColor = BackgroundDeep)
                ) { Text("Save") }
            },
            dismissButton = {
                OutlinedButton(onClick = { editingProfile = null }) { Text("Cancel") }
            },
            title = { Text("Rename Profile", color = TextPrimary) },
            text = {
                OutlinedTextField(
                    value = editName,
                    onValueChange = { editName = it },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = AccentNeonGreen,
                        unfocusedBorderColor = SurfaceCardElevated
                    )
                )
            },
            containerColor = BackgroundDeep
        )
    }

    deletingProfile?.let { profile ->
        AlertDialog(
            onDismissRequest = { deletingProfile = null },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteProfile(profile)
                        deletingProfile = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AccentRed, contentColor = TextPrimary)
                ) { Text("Delete") }
            },
            dismissButton = {
                OutlinedButton(onClick = { deletingProfile = null }) { Text("Cancel") }
            },
            title = { Text("Delete \"${profile.name}\"?", color = TextPrimary) },
            text = { Text("This cannot be undone.", color = TextSecondary) },
            containerColor = BackgroundDeep
        )
    }
}

@Composable
private fun ProfileRow(
    profile: SensitivityProfile,
    onOpen: () -> Unit,
    onToggleStar: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(SurfaceCard)
            .clickable { onOpen() }
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(profile.name, style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(2.dp))
            Text(profile.deviceLabel, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
            Text(
                "Gen ${profile.values.general} • RD ${profile.values.redDot} • 2x ${profile.values.scope2x} • 4x ${profile.values.scope4x} • Snp ${profile.values.sniperScope} • FL ${profile.values.freeLook}",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            StarToggle(isStarred = profile.isStarred, onToggle = onToggleStar)
            IconButton(onClick = onEdit) {
                Icon(Icons.Filled.Edit, contentDescription = "Rename", tint = TextSecondary)
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = AccentRed)
            }
        }
    }
}
