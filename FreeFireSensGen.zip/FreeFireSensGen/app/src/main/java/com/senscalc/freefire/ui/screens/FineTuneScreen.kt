package com.senscalc.freefire.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.senscalc.freefire.calculator.SensitivityAxis
import com.senscalc.freefire.ui.components.DarkCard
import com.senscalc.freefire.ui.components.MicroAdjusterRow
import com.senscalc.freefire.ui.components.ScreenTopBar
import com.senscalc.freefire.ui.theme.BackgroundDeep
import com.senscalc.freefire.ui.theme.DividerColor
import com.senscalc.freefire.ui.theme.TextSecondary
import com.senscalc.freefire.viewmodel.SensitivityViewModel

@Composable
fun FineTuneScreen(
    viewModel: SensitivityViewModel,
    onBack: () -> Unit
) {
    val state by viewModel.uiState.collectAsState()
    val result = state.result

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDeep)
            .padding(horizontal = 20.dp)
    ) {
        ScreenTopBar(title = "Fine-Tune", subtitle = "Micro-adjust any axis by ±1 or ±5", onBack = onBack)
        Spacer(Modifier.height(8.dp))

        if (result == null) {
            Text("Generate a sensitivity first.", color = TextSecondary, style = MaterialTheme.typography.bodyLarge)
            return@Column
        }

        DarkCard(modifier = Modifier.fillMaxWidth()) {
            MicroAdjusterRow("General", result.values.general) { delta ->
                viewModel.microAdjust(SensitivityAxis.GENERAL, delta)
            }
            Divider(color = DividerColor)
            MicroAdjusterRow("Red Dot", result.values.redDot) { delta ->
                viewModel.microAdjust(SensitivityAxis.RED_DOT, delta)
            }
            Divider(color = DividerColor)
            MicroAdjusterRow("2x Scope", result.values.scope2x) { delta ->
                viewModel.microAdjust(SensitivityAxis.SCOPE_2X, delta)
            }
            Divider(color = DividerColor)
            MicroAdjusterRow("4x Scope", result.values.scope4x) { delta ->
                viewModel.microAdjust(SensitivityAxis.SCOPE_4X, delta)
            }
            Divider(color = DividerColor)
            MicroAdjusterRow("Sniper Scope", result.values.sniperScope) { delta ->
                viewModel.microAdjust(SensitivityAxis.SNIPER, delta)
            }
            Divider(color = DividerColor)
            MicroAdjusterRow("Free Look", result.values.freeLook) { delta ->
                viewModel.microAdjust(SensitivityAxis.FREE_LOOK, delta)
            }
        }
    }
}
