package com.senscalc.freefire.ui.navigation

object Destinations {
    const val HOME = "home"
    const val DEVICE_SELECT = "device_select"
    const val CUSTOM_BUILDER = "custom_builder"
    const val RESULT = "result"
    const val PRESET_LIBRARY = "preset_library"
    const val FINE_TUNE = "fine_tune"
    const val HUD_BLUEPRINTS = "hud_blueprints"
    const val DRAG_SIMULATOR = "drag_simulator"
    const val PROFILES = "profiles"
}
