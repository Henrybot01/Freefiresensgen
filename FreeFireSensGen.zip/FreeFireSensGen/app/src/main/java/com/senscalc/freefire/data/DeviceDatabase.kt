package com.senscalc.freefire.data

import com.senscalc.freefire.data.model.ChipsetTier
import com.senscalc.freefire.data.model.DeviceProfile
import com.senscalc.freefire.data.model.GlassFriction
import com.senscalc.freefire.data.model.MetaPreset

/**
 * Static, pre-configured device catalogue covering the major Android
 * brands plus reference iOS profiles for cross-checking. Values are
 * curated approximations of each device's panel refresh rate, touch
 * sampling rate, chipset class, glass coating, and screen DPI.
 */
object DeviceDatabase {

    val devices: List<DeviceProfile> = listOf(
        // ---- Xiaomi / Redmi ----
        DeviceProfile("redmi_14c", "Redmi", "Redmi 14C", 90, 120, ChipsetTier.ENTRY, GlassFriction.HIGH, 260, 4),
        DeviceProfile("redmi_note_13", "Redmi", "Redmi Note 13", 120, 180, ChipsetTier.LOWER_MID, GlassFriction.MEDIUM, 395, 6),
        DeviceProfile("redmi_note_13_pro", "Redmi", "Redmi Note 13 Pro", 120, 240, ChipsetTier.UPPER_MID, GlassFriction.MEDIUM, 395, 8),
        DeviceProfile("xiaomi_13", "Xiaomi", "Xiaomi 13", 120, 360, ChipsetTier.FLAGSHIP, GlassFriction.LOW, 414, 8),
        DeviceProfile("xiaomi_14", "Xiaomi", "Xiaomi 14", 120, 480, ChipsetTier.ELITE, GlassFriction.LOW, 460, 12),

        // ---- POCO ----
        DeviceProfile("poco_c65", "POCO", "POCO C65", 90, 120, ChipsetTier.ENTRY, GlassFriction.HIGH, 267, 4),
        DeviceProfile("poco_x6", "POCO", "POCO X6", 120, 240, ChipsetTier.UPPER_MID, GlassFriction.MEDIUM, 395, 8),
        DeviceProfile("poco_f6", "POCO", "POCO F6", 120, 360, ChipsetTier.FLAGSHIP, GlassFriction.LOW, 446, 8),
        DeviceProfile("poco_x6_pro", "POCO", "POCO X6 Pro", 120, 240, ChipsetTier.UPPER_MID, GlassFriction.MEDIUM, 395, 8),

        // ---- Samsung ----
        DeviceProfile("samsung_a05", "Samsung", "Galaxy A05", 60, 120, ChipsetTier.ENTRY, GlassFriction.HIGH, 267, 4),
        DeviceProfile("samsung_a15", "Samsung", "Galaxy A15", 90, 150, ChipsetTier.LOWER_MID, GlassFriction.MEDIUM, 385, 4),
        DeviceProfile("samsung_a55", "Samsung", "Galaxy A55", 120, 240, ChipsetTier.UPPER_MID, GlassFriction.MEDIUM, 403, 8),
        DeviceProfile("samsung_s23", "Samsung", "Galaxy S23", 120, 360, ChipsetTier.FLAGSHIP, GlassFriction.LOW, 425, 8),
        DeviceProfile("samsung_s24_ultra", "Samsung", "Galaxy S24 Ultra", 120, 480, ChipsetTier.ELITE, GlassFriction.LOW, 505, 12),

        // ---- Infinix ----
        DeviceProfile("infinix_hot_40", "Infinix", "Hot 40", 90, 120, ChipsetTier.ENTRY, GlassFriction.HIGH, 270, 4),
        DeviceProfile("infinix_note_40", "Infinix", "Note 40", 120, 180, ChipsetTier.LOWER_MID, GlassFriction.MEDIUM, 395, 8),
        DeviceProfile("infinix_gt_20_pro", "Infinix", "GT 20 Pro", 144, 360, ChipsetTier.UPPER_MID, GlassFriction.LOW, 395, 8),

        // ---- Tecno ----
        DeviceProfile("tecno_spark_20", "Tecno", "Spark 20", 90, 120, ChipsetTier.ENTRY, GlassFriction.HIGH, 270, 4),
        DeviceProfile("tecno_camon_20", "Tecno", "Camon 20", 120, 180, ChipsetTier.LOWER_MID, GlassFriction.MEDIUM, 395, 8),
        DeviceProfile("tecno_pova_6_pro", "Tecno", "Pova 6 Pro", 120, 240, ChipsetTier.UPPER_MID, GlassFriction.MEDIUM, 395, 8),

        // ---- Realme ----
        DeviceProfile("realme_c67", "Realme", "C67", 90, 120, ChipsetTier.LOWER_MID, GlassFriction.MEDIUM, 264, 6),
        DeviceProfile("realme_11_pro", "Realme", "11 Pro", 120, 240, ChipsetTier.UPPER_MID, GlassFriction.MEDIUM, 394, 8),
        DeviceProfile("realme_gt_5", "Realme", "GT 5", 144, 360, ChipsetTier.FLAGSHIP, GlassFriction.LOW, 450, 12),

        // ---- OnePlus ----
        DeviceProfile("oneplus_nord_ce4", "OnePlus", "Nord CE4", 120, 240, ChipsetTier.UPPER_MID, GlassFriction.MEDIUM, 402, 8),
        DeviceProfile("oneplus_12r", "OnePlus", "12R", 120, 360, ChipsetTier.FLAGSHIP, GlassFriction.LOW, 450, 16),
        DeviceProfile("oneplus_12", "OnePlus", "12", 120, 480, ChipsetTier.ELITE, GlassFriction.LOW, 510, 16),

        // ---- ASUS ROG ----
        DeviceProfile("rog_phone_7", "ASUS", "ROG Phone 7", 165, 720, ChipsetTier.ELITE, GlassFriction.LOW, 395, 16),
        DeviceProfile("rog_phone_8", "ASUS", "ROG Phone 8", 165, 720, ChipsetTier.ELITE, GlassFriction.LOW, 388, 16),
        DeviceProfile("rog_phone_9", "ASUS", "ROG Phone 9", 185, 720, ChipsetTier.ELITE, GlassFriction.LOW, 388, 16),

        // ---- Apple (reference profiles for feel-matching only) ----
        DeviceProfile("iphone_13", "Apple", "iPhone 13", 60, 120, ChipsetTier.FLAGSHIP, GlassFriction.MEDIUM, 460, 4),
        DeviceProfile("iphone_15_pro", "Apple", "iPhone 15 Pro", 120, 240, ChipsetTier.ELITE, GlassFriction.MEDIUM, 460, 8),
        DeviceProfile("ipad_9th", "Apple", "iPad (9th Gen)", 60, 120, ChipsetTier.UPPER_MID, GlassFriction.MEDIUM, 264, 3),
        DeviceProfile("ipad_pro_m2", "Apple", "iPad Pro (M2)", 120, 240, ChipsetTier.ELITE, GlassFriction.LOW, 264, 8)
    )

    val brands: List<String> = devices.map { it.brand }.distinct().sorted()

    fun devicesForBrand(brand: String): List<DeviceProfile> = devices.filter { it.brand == brand }

    fun findById(id: String): DeviceProfile? = devices.find { it.id == id }
}

/**
 * Meta & Preset Library: multipliers layered on top of a device's
 * computed baseline sensitivity.
 */
object PresetLibrary {

    val presets: List<MetaPreset> = listOf(
        MetaPreset(
            id = "tournament_meta",
            title = "Tournament Meta",
            description = "Balanced, competitively-proven curve used by ranked and scrim players. " +
                "Slightly reduced scope sensitivities for controlled spray, faster general/free look for rotations.",
            generalMult = 1.05,
            redDotMult = 1.00,
            scope2xMult = 0.95,
            scope4xMult = 0.90,
            sniperMult = 0.85,
            freeLookMult = 1.10
        ),
        MetaPreset(
            id = "one_tap_headshots",
            title = "One-Tap Headshots",
            description = "Higher red dot and 2x sensitivity for snappy flick shots, tuned for close-to-mid range dueling.",
            generalMult = 1.00,
            redDotMult = 1.20,
            scope2xMult = 1.15,
            scope4xMult = 0.95,
            sniperMult = 0.80,
            freeLookMult = 1.00
        ),
        MetaPreset(
            id = "sniper_specialist",
            title = "Sniper Specialist",
            description = "Lowered 4x/sniper sensitivity for pixel-precise long-range tracking, with quicker free look for re-positioning.",
            generalMult = 0.95,
            redDotMult = 0.95,
            scope2xMult = 0.90,
            scope4xMult = 0.75,
            sniperMult = 0.60,
            freeLookMult = 1.20
        ),
        MetaPreset(
            id = "high_refresh_120",
            title = "High Refresh Rate (120Hz+)",
            description = "Compensated curve for 120Hz+ panels where extra frame data allows higher across-the-board sensitivity without losing control.",
            generalMult = 1.15,
            redDotMult = 1.10,
            scope2xMult = 1.08,
            scope4xMult = 1.00,
            sniperMult = 0.90,
            freeLookMult = 1.15
        )
    )

    fun findById(id: String): MetaPreset? = presets.find { it.id == id }
}
