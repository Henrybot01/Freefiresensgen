package com.senscalc.freefire.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.senscalc.freefire.data.model.SensitivityProfile
import com.senscalc.freefire.data.model.SensitivityValues

@Entity(tableName = "sensitivity_profiles")
data class ProfileEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val name: String,
    val deviceLabel: String,
    val general: Int,
    val redDot: Int,
    val scope2x: Int,
    val scope4x: Int,
    val sniperScope: Int,
    val freeLook: Int,
    val fireButtonSizePercent: Int,
    val targetDpi: Int,
    val isStarred: Boolean,
    val createdAtMillis: Long,
    val updatedAtMillis: Long
)

fun ProfileEntity.toDomain(): SensitivityProfile = SensitivityProfile(
    id = id,
    name = name,
    deviceLabel = deviceLabel,
    values = SensitivityValues(general, redDot, scope2x, scope4x, sniperScope, freeLook),
    fireButtonSizePercent = fireButtonSizePercent,
    targetDpi = targetDpi,
    isStarred = isStarred,
    createdAtMillis = createdAtMillis,
    updatedAtMillis = updatedAtMillis
)

fun SensitivityProfile.toEntity(): ProfileEntity = ProfileEntity(
    id = id,
    name = name,
    deviceLabel = deviceLabel,
    general = values.general,
    redDot = values.redDot,
    scope2x = values.scope2x,
    scope4x = values.scope4x,
    sniperScope = values.sniperScope,
    freeLook = values.freeLook,
    fireButtonSizePercent = fireButtonSizePercent,
    targetDpi = targetDpi,
    isStarred = isStarred,
    createdAtMillis = createdAtMillis,
    updatedAtMillis = updatedAtMillis
)
