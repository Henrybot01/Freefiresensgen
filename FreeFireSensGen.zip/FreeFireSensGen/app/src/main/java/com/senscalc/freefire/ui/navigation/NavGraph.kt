package com.senscalc.freefire.ui.navigation

import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.senscalc.freefire.ui.screens.CustomBuilderScreen
import com.senscalc.freefire.ui.screens.DeviceSelectScreen
import com.senscalc.freefire.ui.screens.DragSimulatorScreen
import com.senscalc.freefire.ui.screens.FineTuneScreen
import com.senscalc.freefire.ui.screens.HomeScreen
import com.senscalc.freefire.ui.screens.HudBlueprintScreen
import com.senscalc.freefire.ui.screens.PresetLibraryScreen
import com.senscalc.freefire.ui.screens.ProfilesScreen
import com.senscalc.freefire.ui.screens.ResultScreen
import com.senscalc.freefire.viewmodel.SensitivityViewModel

@Composable
fun AppNavGraph(navController: NavHostController, viewModel: SensitivityViewModel) {
    NavHost(
        navController = navController,
        startDestination = Destinations.HOME,
        enterTransition = { slideInHorizontally(initialOffsetX = { it / 4 }) + fadeIn() },
        exitTransition = { fadeOut() },
        popEnterTransition = { fadeIn() },
        popExitTransition = { slideOutHorizontally(targetOffsetX = { it / 4 }) + fadeOut() }
    ) {
        composable(Destinations.HOME) {
            HomeScreen(
                viewModel = viewModel,
                onPickDevice = { navController.navigate(Destinations.DEVICE_SELECT) },
                onCustomBuilder = { navController.navigate(Destinations.CUSTOM_BUILDER) },
                onOpenPresets = { navController.navigate(Destinations.PRESET_LIBRARY) },
                onOpenProfiles = { navController.navigate(Destinations.PROFILES) },
                onOpenHud = { navController.navigate(Destinations.HUD_BLUEPRINTS) },
                onOpenSimulator = { navController.navigate(Destinations.DRAG_SIMULATOR) }
            )
        }
        composable(Destinations.DEVICE_SELECT) {
            DeviceSelectScreen(
                onDeviceChosen = {
                    navController.popBackStack(Destinations.HOME, inclusive = false)
                    navController.navigate(Destinations.RESULT)
                },
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Destinations.CUSTOM_BUILDER) {
            CustomBuilderScreen(
                viewModel = viewModel,
                onBuilt = {
                    navController.popBackStack(Destinations.HOME, inclusive = false)
                    navController.navigate(Destinations.RESULT)
                },
                onBack = { navController.popBackStack() }
            )
        }
        composable(Destinations.RESULT) {
            ResultScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onOpenFineTune = { navController.navigate(Destinations.FINE_TUNE) },
                onOpenPresets = { navController.navigate(Destinations.PRESET_LIBRARY) }
            )
        }
        composable(Destinations.PRESET_LIBRARY) {
            PresetLibraryScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Destinations.FINE_TUNE) {
            FineTuneScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Destinations.HUD_BLUEPRINTS) {
            HudBlueprintScreen(onBack = { navController.popBackStack() })
        }
        composable(Destinations.DRAG_SIMULATOR) {
            DragSimulatorScreen(onBack = { navController.popBackStack() })
        }
        composable(Destinations.PROFILES) {
            ProfilesScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onOpenProfile = {
                    navController.popBackStack(Destinations.HOME, inclusive = false)
                    navController.navigate(Destinations.RESULT)
                }
            )
        }
    }
}
