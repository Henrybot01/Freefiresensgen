package com.senscalc.freefire.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.senscalc.freefire.ui.theme.AccentAmber
import com.senscalc.freefire.ui.theme.AccentNeonGreen
import com.senscalc.freefire.ui.theme.AccentRed
import com.senscalc.freefire.ui.theme.SurfaceCard
import com.senscalc.freefire.ui.theme.SurfaceCardElevated
import com.senscalc.freefire.ui.theme.SurfaceStroke
import com.senscalc.freefire.ui.theme.TextPrimary
import com.senscalc.freefire.ui.theme.TextSecondary

/** Standard dark elevated card used across every screen. */
@Composable
fun DarkCard(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScopeAlias.() -> Unit
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(SurfaceCard)
            .padding(18.dp)
    ) {
        content()
    }
}

// Alias to avoid importing ColumnScope directly at call sites in this file's public API.
typealias ColumnScopeAlias = androidx.compose.foundation.layout.ColumnScope

@Composable
fun ScreenTopBar(title: String, subtitle: String? = null, onBack: (() -> Unit)? = null) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
            }
            Spacer(Modifier.width(4.dp))
        }
        Column {
            Text(title, style = MaterialTheme.typography.headlineMedium, color = TextPrimary)
            if (subtitle != null) {
                Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
            }
        }
    }
}

/** Colored ring gauge used to visualize a 0-200 sensitivity value, WHOOP-dial style. */
@Composable
fun SensitivityGaugeCard(
    label: String,
    value: Int,
    modifier: Modifier = Modifier
) {
    val fraction = (value / 200f).coerceIn(0f, 1f)
    val animatedFraction by animateFloatAsState(
        targetValue = fraction,
        animationSpec = tween(durationMillis = 600),
        label = "gaugeAnim"
    )
    val ringColor = when {
        value >= 140 -> AccentNeonGreen
        value >= 70 -> AccentAmber
        else -> AccentRed
    }

    DarkCard(modifier = modifier) {
        Text(label, style = MaterialTheme.typography.labelLarge, color = TextSecondary)
        Spacer(Modifier.height(10.dp))
        Box(
            modifier = Modifier
                .aspectRatio(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxWidth().aspectRatio(1f)) {
                val strokeWidth = size.minDimension * 0.11f
                drawArc(
                    color = SurfaceStroke,
                    startAngle = -90f,
                    sweepAngle = 360f,
                    useCenter = false,
                    style = androidx.compose.ui.graphics.drawscope.Stroke(
                        width = strokeWidth,
                        cap = androidx.compose.ui.graphics.StrokeCap.Round
                    )
                )
                drawArc(
                    color = ringColor,
                    startAngle = -90f,
                    sweepAngle = 360f * animatedFraction,
                    useCenter = false,
                    style = androidx.compose.ui.graphics.drawscope.Stroke(
                        width = strokeWidth,
                        cap = androidx.compose.ui.graphics.StrokeCap.Round
                    )
                )
            }
            Text(
                "$value",
                style = MaterialTheme.typography.headlineLarge,
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

/** +delta / -delta micro-adjuster row used in the Fine-Tuning screen. */
@Composable
fun MicroAdjusterRow(
    label: String,
    value: Int,
    onDelta: (Int) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.width(96.dp)) {
            Text(label, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
            Text("$value", style = MaterialTheme.typography.titleLarge, color = TextPrimary, fontWeight = FontWeight.Bold)
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            AdjusterButton(text = "-5") { onDelta(-5) }
            AdjusterButton(text = "-1") { onDelta(-1) }
            AdjusterButton(text = "+1") { onDelta(1) }
            AdjusterButton(text = "+5") { onDelta(5) }
        }
    }
}

@Composable
private fun AdjusterButton(text: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(width = 44.dp, height = 36.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(SurfaceCardElevated)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(text, style = MaterialTheme.typography.labelLarge, color = AccentNeonGreen)
    }
}

@Composable
fun StatChip(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(SurfaceCardElevated)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Spacer(Modifier.height(4.dp))
        Text(value, style = MaterialTheme.typography.titleLarge, color = AccentNeonGreen, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun PrimaryActionCard(
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    accent: Color = AccentNeonGreen
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.horizontalGradient(
                    listOf(SurfaceCardElevated, SurfaceCard)
                )
            )
            .clickable { onClick() }
            .padding(18.dp)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(accent)
            )
            Spacer(Modifier.height(10.dp))
            Text(title, style = MaterialTheme.typography.titleLarge, color = TextPrimary, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
        }
    }
}

@Composable
fun StarToggle(isStarred: Boolean, onToggle: () -> Unit) {
    IconButton(onClick = onToggle) {
        Icon(
            imageVector = if (isStarred) Icons.Filled.Star else Icons.Filled.StarBorder,
            contentDescription = "Star profile",
            tint = if (isStarred) AccentAmber else TextSecondary
        )
    }
}
