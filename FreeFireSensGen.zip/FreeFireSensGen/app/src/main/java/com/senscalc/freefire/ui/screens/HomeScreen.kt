package com.senscalc.freefire.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.senscalc.freefire.ui.components.PrimaryActionCard
import com.senscalc.freefire.ui.theme.AccentAmber
import com.senscalc.freefire.ui.theme.AccentNeonBlue
import com.senscalc.freefire.ui.theme.AccentNeonGreen
import com.senscalc.freefire.ui.theme.BackgroundDeep
import com.senscalc.freefire.ui.theme.TextPrimary
import com.senscalc.freefire.ui.theme.TextSecondary
import com.senscalc.freefire.viewmodel.SensitivityViewModel

private data class HomeAction(
    val title: String,
    val subtitle: String,
    val accent: androidx.compose.ui.graphics.Color,
    val onClick: () -> Unit
)

@Composable
fun HomeScreen(
    viewModel: SensitivityViewModel,
    onPickDevice: () -> Unit,
    onCustomBuilder: () -> Unit,
    onOpenPresets: () -> Unit,
    onOpenProfiles: () -> Unit,
    onOpenHud: () -> Unit,
    onOpenSimulator: () -> Unit
) {
    val savedProfiles by viewModel.savedProfiles.collectAsState()

    val actions = listOf(
        HomeAction(
            "Pick Your Device",
            "Choose from ${com.senscalc.freefire.data.DeviceDatabase.devices.size}+ preloaded phones & tablets",
            AccentNeonGreen,
            onPickDevice
        ),
        HomeAction(
            "Custom Device Builder",
            "Manually enter refresh rate, RAM & touch specs",
            AccentNeonBlue,
            onCustomBuilder
        ),
        HomeAction(
            "Meta & Preset Library",
            "Tournament Meta, One-Tap Headshots, Sniper Specialist & more",
            AccentAmber,
            onOpenPresets
        ),
        HomeAction(
            "HUD Grip Blueprints",
            "2 / 3 / 4-finger claw layout diagrams",
            AccentNeonBlue,
            onOpenHud
        ),
        HomeAction(
            "Drag Physics Simulator",
            "Preview crosshair resistance & drag-up speed",
            AccentNeonGreen,
            onOpenSimulator
        ),
        HomeAction(
            "Saved Profiles (${savedProfiles.size})",
            "View, star, edit or delete your saved configs",
            AccentAmber,
            onOpenProfiles
        )
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDeep)
            .padding(horizontal = 20.dp)
    ) {
        Spacer(Modifier.height(28.dp))
        Text("FF SENS", style = MaterialTheme.typography.displayLarge, color = TextPrimary)
        Text(
            "Free Fire Sensitivity Generator",
            style = MaterialTheme.typography.bodyLarge,
            color = TextSecondary
        )
        Spacer(Modifier.height(24.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) {
            items(actions) { action ->
                PrimaryActionCard(
                    title = action.title,
                    subtitle = action.subtitle,
                    accent = action.accent,
                    onClick = action.onClick
                )
            }
        }
    }
}
