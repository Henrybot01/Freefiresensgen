package com.senscalc.freefire.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.senscalc.freefire.data.model.ChipsetTier
import com.senscalc.freefire.data.model.GlassFriction
import com.senscalc.freefire.ui.components.DarkCard
import com.senscalc.freefire.ui.components.ScreenTopBar
import com.senscalc.freefire.ui.theme.AccentNeonGreen
import com.senscalc.freefire.ui.theme.BackgroundDeep
import com.senscalc.freefire.ui.theme.SurfaceCardElevated
import com.senscalc.freefire.ui.theme.TextPrimary
import com.senscalc.freefire.ui.theme.TextSecondary
import com.senscalc.freefire.viewmodel.SensitivityViewModel

@Composable
fun CustomBuilderScreen(
    viewModel: SensitivityViewModel,
    onBuilt: () -> Unit,
    onBack: () -> Unit
) {
    val state by viewModel.uiState.collectAsState()
    var deviceName by remember { mutableStateOf("") }
    var refreshRate by remember { mutableStateOf(state.customRefreshRate.toFloat()) }
    var touchSampling by remember { mutableStateOf(state.customTouchSampling.toFloat()) }
    var dpi by remember { mutableStateOf(state.customDpi.toFloat()) }
    var ram by remember { mutableStateOf(state.customRam.toFloat()) }
    var chipsetTier by remember { mutableStateOf(state.customChipsetTier) }
    var glassFriction by remember { mutableStateOf(state.customGlassFriction) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDeep)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
    ) {
        ScreenTopBar(title = "Custom Device Builder", subtitle = "For unlisted phones & tablets", onBack = onBack)
        Spacer(Modifier.height(8.dp))

        DarkCard(modifier = Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = deviceName,
                onValueChange = { deviceName = it },
                label = { Text("Device name (optional)") },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedBorderColor = AccentNeonGreen,
                    unfocusedBorderColor = SurfaceCardElevated,
                    focusedLabelColor = AccentNeonGreen,
                    unfocusedLabelColor = TextSecondary
                )
            )
        }

        Spacer(Modifier.height(16.dp))

        LabeledSlider(
            label = "Screen Refresh Rate",
            value = refreshRate,
            valueRange = 60f..185f,
            steps = 24,
            unit = "Hz",
            onChange = { refreshRate = it }
        )

        LabeledSlider(
            label = "Touch Sampling Rate",
            value = touchSampling,
            valueRange = 60f..720f,
            steps = 65,
            unit = "Hz",
            onChange = { touchSampling = it }
        )

        LabeledSlider(
            label = "Screen DPI",
            value = dpi,
            valueRange = 200f..550f,
            steps = 34,
            unit = "dpi",
            onChange = { dpi = it }
        )

        LabeledSlider(
            label = "RAM",
            value = ram,
            valueRange = 2f..24f,
            steps = 21,
            unit = "GB",
            onChange = { ram = it }
        )

        Spacer(Modifier.height(8.dp))
        Text("Chipset Performance Tier", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
        Spacer(Modifier.height(8.dp))
        SegmentedChipRow(
            options = ChipsetTier.values().toList(),
            selected = chipsetTier,
            label = { it.label },
            onSelect = { chipsetTier = it }
        )

        Spacer(Modifier.height(16.dp))
        Text("Screen Glass Friction Profile", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
        Spacer(Modifier.height(8.dp))
        SegmentedChipRow(
            options = GlassFriction.values().toList(),
            selected = glassFriction,
            label = { it.label },
            onSelect = { glassFriction = it }
        )

        Spacer(Modifier.height(24.dp))

        Button(
            onClick = {
                viewModel.updateCustomSpecs(
                    refreshRate = refreshRate.toInt(),
                    touchSampling = touchSampling.toInt(),
                    chipsetTier = chipsetTier,
                    glassFriction = glassFriction,
                    dpi = dpi.toInt(),
                    ram = ram.toInt()
                )
                viewModel.buildCustomDeviceAndCalculate(deviceName)
                onBuilt()
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AccentNeonGreen, contentColor = BackgroundDeep)
        ) {
            Text("Generate Sensitivity", style = MaterialTheme.typography.titleMedium)
        }
        Spacer(Modifier.height(32.dp))
    }
}

@Composable
private fun LabeledSlider(
    label: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    steps: Int,
    unit: String,
    onChange: (Float) -> Unit
) {
    Column(modifier = Modifier.padding(vertical = 8.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
            Text("${value.toInt()} $unit", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
        }
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = valueRange,
            steps = steps,
            colors = SliderDefaults.colors(
                thumbColor = AccentNeonGreen,
                activeTrackColor = AccentNeonGreen,
                inactiveTrackColor = SurfaceCardElevated
            )
        )
    }
}

@Composable
private fun <T> SegmentedChipRow(
    options: List<T>,
    selected: T,
    label: (T) -> String,
    onSelect: (T) -> Unit
) {
    Column {
        // Rendered two-per-row so long labels never get clipped, without
        // relying on the experimental FlowRow API.
        options.chunked(2).forEach { rowOptions ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                rowOptions.forEach { option ->
                    val isSelected = option == selected
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .background(
                                color = if (isSelected) AccentNeonGreen else SurfaceCardElevated,
                                shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
                            )
                            .clickable { onSelect(option) }
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            label(option),
                            style = MaterialTheme.typography.labelMedium,
                            color = if (isSelected) BackgroundDeep else TextSecondary
                        )
                    }
                }
                if (rowOptions.size == 1) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }
    }
}
