package com.senscalc.freefire.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.senscalc.freefire.ui.components.ScreenTopBar
import com.senscalc.freefire.ui.components.SensitivityGaugeCard
import com.senscalc.freefire.ui.components.StatChip
import com.senscalc.freefire.ui.theme.AccentNeonGreen
import com.senscalc.freefire.ui.theme.BackgroundDeep
import com.senscalc.freefire.ui.theme.SurfaceCardElevated
import com.senscalc.freefire.ui.theme.TextPrimary
import com.senscalc.freefire.ui.theme.TextSecondary
import com.senscalc.freefire.viewmodel.SensitivityViewModel

@Composable
fun ResultScreen(
    viewModel: SensitivityViewModel,
    onBack: () -> Unit,
    onOpenFineTune: () -> Unit,
    onOpenPresets: () -> Unit
) {
    val state by viewModel.uiState.collectAsState()
    val result = state.result
    var showSaveDialog by remember { mutableStateOf(false) }
    var profileName by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDeep)
            .padding(horizontal = 20.dp)
    ) {
        ScreenTopBar(
            title = "Your Sensitivity",
            subtitle = state.selectedDevice?.let { "${it.brand} ${it.model}" } ?: "Custom configuration",
            onBack = onBack
        )

        if (result == null) {
            Spacer(Modifier.height(24.dp))
            Text("No result yet — pick a device first.", color = TextSecondary, style = MaterialTheme.typography.bodyLarge)
            return@Column
        }

        Column(modifier = Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            LazyGridResults(values = result.values)

            Spacer(Modifier.height(16.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatChip(label = "Fire Button Size", value = "${result.fireButtonSizePercent}%", modifier = Modifier.weight(1f))
                StatChip(label = "Target DPI", value = "${result.targetDpi}", modifier = Modifier.weight(1f))
            }

            state.selectedPreset?.let { preset ->
                Spacer(Modifier.height(12.dp))
                Text("Preset applied: ${preset.title}", style = MaterialTheme.typography.bodyMedium, color = AccentNeonGreen)
            }

            Spacer(Modifier.height(24.dp))
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = onOpenPresets,
                modifier = Modifier.weight(1f)
            ) {
                Text("Presets")
            }
            OutlinedButton(
                onClick = onOpenFineTune,
                modifier = Modifier.weight(1f)
            ) {
                Text("Fine-Tune")
            }
        }

        Button(
            onClick = { showSaveDialog = true },
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .padding(bottom = 24.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AccentNeonGreen, contentColor = BackgroundDeep)
        ) {
            Text("Save Profile", style = MaterialTheme.typography.titleMedium)
        }
    }

    if (showSaveDialog) {
        AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.saveCurrentAsProfile(profileName)
                        showSaveDialog = false
                        profileName = ""
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AccentNeonGreen, contentColor = BackgroundDeep)
                ) { Text("Save") }
            },
            dismissButton = {
                OutlinedButton(onClick = { showSaveDialog = false }) { Text("Cancel") }
            },
            title = { Text("Name this profile", color = TextPrimary) },
            text = {
                OutlinedTextField(
                    value = profileName,
                    onValueChange = { profileName = it },
                    placeholder = { Text("e.g. Sniper Loadout") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = AccentNeonGreen,
                        unfocusedBorderColor = SurfaceCardElevated
                    )
                )
            },
            containerColor = BackgroundDeep
        )
    }
}

@Composable
private fun LazyGridResults(values: com.senscalc.freefire.data.model.SensitivityValues) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier
            .fillMaxWidth()
            .height(420.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 4.dp)
    ) {
        val entries = listOf(
            "General" to values.general,
            "Red Dot" to values.redDot,
            "2x Scope" to values.scope2x,
            "4x Scope" to values.scope4x,
            "Sniper Scope" to values.sniperScope,
            "Free Look" to values.freeLook
        )
        items(entries) { (label, value) ->
            SensitivityGaugeCard(label = label, value = value)
        }
    }
}
