package com.senscalc.freefire

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.compose.rememberNavController
import com.senscalc.freefire.data.db.AppDatabase
import com.senscalc.freefire.data.repository.ProfileRepository
import com.senscalc.freefire.ui.navigation.AppNavGraph
import com.senscalc.freefire.ui.theme.BackgroundDeep
import com.senscalc.freefire.ui.theme.FreeFireSensGenTheme
import com.senscalc.freefire.viewmodel.SensitivityViewModel
import com.senscalc.freefire.viewmodel.ViewModelFactory

class MainActivity : ComponentActivity() {

    private val repository: ProfileRepository by lazy {
        ProfileRepository(AppDatabase.getInstance(applicationContext).profileDao())
    }

    private val viewModel: SensitivityViewModel by viewModels { ViewModelFactory(repository) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FreeFireSensGenApp(viewModel = viewModel)
        }
    }
}

@Composable
fun FreeFireSensGenApp(viewModel: SensitivityViewModel) {
    FreeFireSensGenTheme {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .background(BackgroundDeep)
        ) {
            val navController = rememberNavController()
            AppNavGraph(navController = navController, viewModel = viewModel)
        }
    }
}
