package com.senscalc.freefire.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.senscalc.freefire.data.model.GripStyle
import com.senscalc.freefire.ui.components.DarkCard
import com.senscalc.freefire.ui.components.ScreenTopBar
import com.senscalc.freefire.ui.theme.AccentAmber
import com.senscalc.freefire.ui.theme.AccentNeonBlue
import com.senscalc.freefire.ui.theme.AccentNeonGreen
import com.senscalc.freefire.ui.theme.AccentRed
import com.senscalc.freefire.ui.theme.BackgroundDeep
import com.senscalc.freefire.ui.theme.SurfaceCardElevated
import com.senscalc.freefire.ui.theme.SurfaceStroke
import com.senscalc.freefire.ui.theme.TextPrimary
import com.senscalc.freefire.ui.theme.TextSecondary

private data class FingerZone(val label: String, val cx: Float, val cy: Float, val radius: Float, val color: Color)

@Composable
fun HudBlueprintScreen(onBack: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDeep)
            .padding(horizontal = 20.dp)
    ) {
        ScreenTopBar(title = "HUD Grip Blueprints", subtitle = "Recommended finger placement by claw style", onBack = onBack)

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(18.dp),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) {
            items(GripStyle.values().toList()) { style ->
                GripBlueprintCard(style)
            }
        }
    }
}

@Composable
private fun GripBlueprintCard(style: GripStyle) {
    DarkCard(modifier = Modifier.fillMaxWidth()) {
        Text(style.label, style = MaterialTheme.typography.titleLarge, color = TextPrimary, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(descriptionFor(style), style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
        Spacer(Modifier.height(14.dp))

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 10f)
                .background(SurfaceCardElevated)
        ) {
            val w = size.width
            val h = size.height

            // Phone bezel outline
            drawRoundRect(
                color = SurfaceStroke,
                topLeft = Offset(w * 0.06f, h * 0.04f),
                size = androidx.compose.ui.geometry.Size(w * 0.88f, h * 0.92f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(24f, 24f),
                style = Stroke(width = 4f)
            )

            // Left virtual joystick (movement)
            drawCircle(
                color = AccentNeonBlue.copy(alpha = 0.35f),
                radius = w * 0.10f,
                center = Offset(w * 0.20f, h * 0.72f)
            )
            drawCircle(
                color = AccentNeonBlue,
                radius = w * 0.045f,
                center = Offset(w * 0.20f, h * 0.72f)
            )

            // Right side aim/crosshair zone
            drawCircle(
                color = AccentNeonGreen.copy(alpha = 0.20f),
                radius = w * 0.22f,
                center = Offset(w * 0.72f, h * 0.45f)
            )

            val zones = zonesFor(style, w, h)
            zones.forEach { zone ->
                drawCircle(color = zone.color.copy(alpha = 0.85f), radius = zone.radius, center = Offset(zone.cx, zone.cy))
                drawCircle(color = zone.color, radius = zone.radius, center = Offset(zone.cx, zone.cy), style = Stroke(width = 3f))
            }
        }

        Spacer(Modifier.height(10.dp))
        zonesLegend(style)
    }
}

@Composable
private fun zonesLegend(style: GripStyle) {
    val labels = when (style) {
        GripStyle.TWO_FINGER -> listOf("Thumb: Move + Fire" to AccentNeonGreen, "Thumb: Aim + Scope" to AccentAmber)
        GripStyle.THREE_FINGER -> listOf(
            "Thumb: Move" to AccentNeonBlue,
            "Index: Fire" to AccentNeonGreen,
            "Thumb: Aim/Scope" to AccentAmber
        )
        GripStyle.FOUR_FINGER -> listOf(
            "Thumb: Move" to AccentNeonBlue,
            "Index: Fire" to AccentNeonGreen,
            "Index: Scope" to AccentAmber,
            "Thumb: Aim/Drag" to AccentRed
        )
    }
    Column {
        labels.forEach { (label, color) ->
            androidx.compose.foundation.layout.Row(
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                modifier = Modifier.padding(vertical = 3.dp)
            ) {
                androidx.compose.foundation.layout.Box(
                    modifier = Modifier
                        .height(10.dp)
                        .fillMaxWidth(0.03f)
                        .background(color, androidx.compose.foundation.shape.CircleShape)
                )
                Spacer(Modifier.width(8.dp))
                Text(label, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
            }
        }
    }
}

private fun descriptionFor(style: GripStyle): String = when (style) {
    GripStyle.TWO_FINGER -> "Beginner-friendly: left thumb moves and fires via the auto-fire toggle, right thumb handles aim and scope."
    GripStyle.THREE_FINGER -> "Balanced control: left thumb moves, right index finger rests on a floating fire button, right thumb free-aims."
    GripStyle.FOUR_FINGER -> "Competitive claw: left thumb moves, right index fires, right middle/second finger scopes, right thumb free-aims and drags."
}

private fun zonesFor(style: GripStyle, w: Float, h: Float): List<FingerZone> = when (style) {
    GripStyle.TWO_FINGER -> listOf(
        FingerZone("move_fire", w * 0.20f, h * 0.72f, w * 0.045f, AccentNeonGreen),
        FingerZone("aim_scope", w * 0.75f, h * 0.40f, w * 0.045f, AccentAmber)
    )
    GripStyle.THREE_FINGER -> listOf(
        FingerZone("move", w * 0.20f, h * 0.72f, w * 0.04f, AccentNeonBlue),
        FingerZone("fire", w * 0.86f, h * 0.62f, w * 0.045f, AccentNeonGreen),
        FingerZone("aim_scope", w * 0.68f, h * 0.32f, w * 0.045f, AccentAmber)
    )
    GripStyle.FOUR_FINGER -> listOf(
        FingerZone("move", w * 0.20f, h * 0.72f, w * 0.04f, AccentNeonBlue),
        FingerZone("fire", w * 0.88f, h * 0.68f, w * 0.04f, AccentNeonGreen),
        FingerZone("scope", w * 0.80f, h * 0.28f, w * 0.04f, AccentAmber),
        FingerZone("aim_drag", w * 0.55f, h * 0.45f, w * 0.045f, AccentRed)
    )
}
