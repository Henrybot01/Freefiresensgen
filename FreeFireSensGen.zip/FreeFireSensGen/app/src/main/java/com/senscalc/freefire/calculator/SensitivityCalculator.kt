package com.senscalc.freefire.calculator

import com.senscalc.freefire.data.model.DeviceProfile
import com.senscalc.freefire.data.model.MetaPreset
import com.senscalc.freefire.data.model.SensitivityResult
import com.senscalc.freefire.data.model.SensitivityValues
import kotlin.math.roundToInt

/**
 * Deterministic calculation engine that converts hardware characteristics
 * into the six Free Fire sensitivity axes plus fire button size and
 * target DPI recommendations.
 *
 * The model works in five stages:
 *  1. Normalize each hardware input into a multiplicative factor.
 *  2. Combine factors into a single "general" baseline (0-200 scale).
 *  3. Derive the other five axes from the baseline using fixed ratios
 *     that reflect how much finer control each scope level needs.
 *  4. Optionally apply a Meta Preset's per-axis multipliers on top.
 *  5. Compute fire button size (%) and target DPI recommendations.
 */
object SensitivityCalculator {

    private const val BASE_VALUE = 100.0

    private fun refreshRateFactor(hz: Int): Double = when {
        hz <= 60 -> 0.85
        hz <= 90 -> 0.95
        hz <= 120 -> 1.10
        hz <= 144 -> 1.18
        hz <= 165 -> 1.22
        else -> 1.28
    }

    private fun chipsetFactor(tier: Int): Double = 0.80 + (tier * 0.08)

    private fun touchSamplingFactor(hz: Int): Double = (hz / 240.0).coerceIn(0.70, 1.35)

    private fun dpiFactor(dpi: Int): Double = (400.0 / dpi.coerceAtLeast(1)).coerceIn(0.80, 1.20)

    /**
     * Computes the baseline "General" sensitivity (0-200) from raw
     * hardware characteristics.
     */
    fun computeGeneralBaseline(
        refreshRateHz: Int,
        touchSamplingHz: Int,
        chipsetTierValue: Int,
        glassFrictionFactor: Double,
        screenDpi: Int
    ): Double {
        val combined = BASE_VALUE *
            refreshRateFactor(refreshRateHz) *
            chipsetFactor(chipsetTierValue) *
            touchSamplingFactor(touchSamplingHz) *
            glassFrictionFactor *
            dpiFactor(screenDpi)
        return combined.coerceIn(0.0, 200.0)
    }

    /**
     * Full calculation for a given device profile, optionally layering
     * a Meta Preset's axis multipliers on top of the computed baseline.
     */
    fun calculate(device: DeviceProfile, preset: MetaPreset? = null): SensitivityResult {
        val general = computeGeneralBaseline(
            refreshRateHz = device.refreshRateHz,
            touchSamplingHz = device.touchSamplingHz,
            chipsetTierValue = device.chipsetTier.tier,
            glassFrictionFactor = device.glassFriction.factor,
            screenDpi = device.screenDpi
        )

        // Fixed ratios reflecting how much finer control each zoom level
        // typically needs relative to the general baseline.
        val redDotRatio = 0.95
        val scope2xRatio = 0.80
        val scope4xRatio = 0.62
        val sniperRatio = 0.45
        val freeLookRatio = 1.15

        val gMult = preset?.generalMult ?: 1.0
        val rMult = preset?.redDotMult ?: 1.0
        val s2Mult = preset?.scope2xMult ?: 1.0
        val s4Mult = preset?.scope4xMult ?: 1.0
        val snMult = preset?.sniperMult ?: 1.0
        val flMult = preset?.freeLookMult ?: 1.0

        val values = SensitivityValues(
            general = (general * gMult).roundToInt(),
            redDot = (general * redDotRatio * rMult).roundToInt(),
            scope2x = (general * scope2xRatio * s2Mult).roundToInt(),
            scope4x = (general * scope4xRatio * s4Mult).roundToInt(),
            sniperScope = (general * sniperRatio * snMult).roundToInt(),
            freeLook = (general * freeLookRatio * flMult).roundToInt()
        ).clampAll()

        val fireButtonSize = computeFireButtonSize(device)
        val targetDpi = computeTargetDpi(device)

        return SensitivityResult(
            values = values,
            fireButtonSizePercent = fireButtonSize,
            targetDpi = targetDpi
        )
    }

    /**
     * Recommended fire button size as a percentage of the HUD scale.
     * Lower-tier chipsets and lower touch sampling rates get a
     * slightly larger button to reduce mis-taps; higher-tier hardware
     * can afford a smaller, less obstructive button.
     */
    fun computeFireButtonSize(device: DeviceProfile): Int {
        val base = 18.0
        val chipsetAdjustment = (device.chipsetTier.tier - 1) * 0.9 // higher tier -> smaller button
        val touchAdjustment = when {
            device.touchSamplingHz >= 360 -> 1.5
            device.touchSamplingHz >= 240 -> 0.7
            else -> 0.0
        }
        val size = base - chipsetAdjustment - touchAdjustment
        return size.roundToInt().coerceIn(8, 20)
    }

    /**
     * Recommended target screen DPI setting (in Free Fire's own DPI
     * slider, not the physical panel DPI) rounded to the nearest 10,
     * scaled from the device's physical screen DPI and refresh rate.
     */
    fun computeTargetDpi(device: DeviceProfile): Int {
        val refreshBoost = when {
            device.refreshRateHz >= 144 -> 1.08
            device.refreshRateHz >= 120 -> 1.04
            else -> 1.0
        }
        val raw = (device.screenDpi * 0.65 * refreshBoost)
        val rounded = (raw / 10.0).roundToInt() * 10
        return rounded.coerceIn(200, 500)
    }

    /**
     * Applies a micro-adjustment (e.g. +1/-1 or +5/-5) to one axis of
     * an existing SensitivityValues set, clamping to the 0-200 range.
     */
    fun adjust(values: SensitivityValues, axis: SensitivityAxis, delta: Int): SensitivityValues {
        return when (axis) {
            SensitivityAxis.GENERAL -> values.copy(general = values.general + delta)
            SensitivityAxis.RED_DOT -> values.copy(redDot = values.redDot + delta)
            SensitivityAxis.SCOPE_2X -> values.copy(scope2x = values.scope2x + delta)
            SensitivityAxis.SCOPE_4X -> values.copy(scope4x = values.scope4x + delta)
            SensitivityAxis.SNIPER -> values.copy(sniperScope = values.sniperScope + delta)
            SensitivityAxis.FREE_LOOK -> values.copy(freeLook = values.freeLook + delta)
        }.clampAll()
    }
}

enum class SensitivityAxis(val displayName: String) {
    GENERAL("General"),
    RED_DOT("Red Dot"),
    SCOPE_2X("2x Scope"),
    SCOPE_4X("4x Scope"),
    SNIPER("Sniper Scope"),
    FREE_LOOK("Free Look")
}
