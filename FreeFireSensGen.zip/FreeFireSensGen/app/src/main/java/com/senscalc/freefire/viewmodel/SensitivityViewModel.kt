package com.senscalc.freefire.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.senscalc.freefire.calculator.SensitivityAxis
import com.senscalc.freefire.calculator.SensitivityCalculator
import com.senscalc.freefire.data.DeviceDatabase
import com.senscalc.freefire.data.model.ChipsetTier
import com.senscalc.freefire.data.model.DeviceProfile
import com.senscalc.freefire.data.model.GlassFriction
import com.senscalc.freefire.data.model.MetaPreset
import com.senscalc.freefire.data.model.SensitivityProfile
import com.senscalc.freefire.data.model.SensitivityResult
import com.senscalc.freefire.data.repository.ProfileRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

/**
 * Immutable snapshot of everything the UI needs to render at any
 * point in the calculator flow.
 */
data class SensitivityUiState(
    val selectedDevice: DeviceProfile? = null,
    val selectedPreset: MetaPreset? = null,
    val result: SensitivityResult? = null,
    val customRefreshRate: Int = 120,
    val customTouchSampling: Int = 240,
    val customChipsetTier: ChipsetTier = ChipsetTier.UPPER_MID,
    val customGlassFriction: GlassFriction = GlassFriction.MEDIUM,
    val customDpi: Int = 400,
    val customRam: Int = 8
)

class SensitivityViewModel(private val repository: ProfileRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(SensitivityUiState())
    val uiState: StateFlow<SensitivityUiState> = _uiState

    val savedProfiles: StateFlow<List<SensitivityProfile>> = repository.observeProfiles()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun selectDevice(device: DeviceProfile) {
        val result = SensitivityCalculator.calculate(device, _uiState.value.selectedPreset)
        _uiState.value = _uiState.value.copy(selectedDevice = device, result = result)
    }

    fun applyPreset(preset: MetaPreset?) {
        val device = _uiState.value.selectedDevice ?: return
        val result = SensitivityCalculator.calculate(device, preset)
        _uiState.value = _uiState.value.copy(selectedPreset = preset, result = result)
    }

    fun updateCustomSpecs(
        refreshRate: Int = _uiState.value.customRefreshRate,
        touchSampling: Int = _uiState.value.customTouchSampling,
        chipsetTier: ChipsetTier = _uiState.value.customChipsetTier,
        glassFriction: GlassFriction = _uiState.value.customGlassFriction,
        dpi: Int = _uiState.value.customDpi,
        ram: Int = _uiState.value.customRam
    ) {
        _uiState.value = _uiState.value.copy(
            customRefreshRate = refreshRate,
            customTouchSampling = touchSampling,
            customChipsetTier = chipsetTier,
            customGlassFriction = glassFriction,
            customDpi = dpi,
            customRam = ram
        )
    }

    fun buildCustomDeviceAndCalculate(deviceName: String) {
        val s = _uiState.value
        val custom = DeviceProfile(
            id = "custom_${UUID.randomUUID()}",
            brand = "Custom",
            model = deviceName.ifBlank { "Custom Device" },
            refreshRateHz = s.customRefreshRate,
            touchSamplingHz = s.customTouchSampling,
            chipsetTier = s.customChipsetTier,
            glassFriction = s.customGlassFriction,
            screenDpi = s.customDpi,
            ramGb = s.customRam,
            isCustom = true
        )
        selectDevice(custom)
    }

    fun microAdjust(axis: SensitivityAxis, delta: Int) {
        val current = _uiState.value.result ?: return
        val adjustedValues = SensitivityCalculator.adjust(current.values, axis, delta)
        _uiState.value = _uiState.value.copy(result = current.copy(values = adjustedValues))
    }

    fun overwriteResult(result: SensitivityResult) {
        _uiState.value = _uiState.value.copy(result = result)
    }

    fun saveCurrentAsProfile(name: String, onSaved: (Long) -> Unit = {}) {
        val state = _uiState.value
        val result = state.result ?: return
        val deviceLabel = state.selectedDevice?.let { "${it.brand} ${it.model}" } ?: "Unknown Device"
        val profile = SensitivityProfile(
            name = name.ifBlank { "Untitled Profile" },
            deviceLabel = deviceLabel,
            values = result.values,
            fireButtonSizePercent = result.fireButtonSizePercent,
            targetDpi = result.targetDpi
        )
        viewModelScope.launch {
            val id = repository.saveNew(profile)
            onSaved(id)
        }
    }

    fun updateProfile(profile: SensitivityProfile) {
        viewModelScope.launch { repository.update(profile) }
    }

    fun deleteProfile(profile: SensitivityProfile) {
        viewModelScope.launch { repository.delete(profile) }
    }

    fun toggleStar(profile: SensitivityProfile) {
        viewModelScope.launch { repository.setStarred(profile.id, !profile.isStarred) }
    }

    fun loadProfileIntoEditor(profile: SensitivityProfile) {
        val result = SensitivityResult(
            values = profile.values,
            fireButtonSizePercent = profile.fireButtonSizePercent,
            targetDpi = profile.targetDpi
        )
        _uiState.value = _uiState.value.copy(result = result, selectedDevice = null, selectedPreset = null)
    }

    companion object {
        fun defaultDeviceOnFirstLaunch(): DeviceProfile = DeviceDatabase.devices.first()
    }
}
